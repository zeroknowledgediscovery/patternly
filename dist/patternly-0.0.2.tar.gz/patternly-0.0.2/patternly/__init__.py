from patternly.utils import RANDOM_NAME, os_remove
from patternly.detection import AnomalyDetection