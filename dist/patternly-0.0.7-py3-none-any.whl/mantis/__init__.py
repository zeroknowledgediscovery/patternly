from mantis._version import __version__
from mantis.utils import RANDOM_NAME, os_remove
from mantis.detection import AnomalyDetection